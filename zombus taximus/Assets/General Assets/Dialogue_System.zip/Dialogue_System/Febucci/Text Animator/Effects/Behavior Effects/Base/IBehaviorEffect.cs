﻿//you can delete this file, it won't be included in the next version

//Faq: why is it empty?
//this empty file acts like a "soft" delete, so we can stay sure it contains nothing that will throw errors in the project, since this old class is no longer used

//no worries, once you build your game this asset will be excluded from it (since it's never referenced anywhere)

//if you still have this file in your project it means that while updating the package this file hasn't been correctly deleted. Feel free to delete it 