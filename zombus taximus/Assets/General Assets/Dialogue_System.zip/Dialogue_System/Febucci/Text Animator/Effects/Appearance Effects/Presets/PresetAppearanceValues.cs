﻿using UnityEngine;

namespace Febucci.UI.Core
{
    [System.Serializable]
    public class PresetAppearanceValues : PresetBaseValues
    {
        public PresetAppearanceValues() : base(true)
        {

        }
    }
}