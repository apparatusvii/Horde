﻿//you can delete this file, it won't be included in the next version

//read more in the IBehaviorEffect.cs file