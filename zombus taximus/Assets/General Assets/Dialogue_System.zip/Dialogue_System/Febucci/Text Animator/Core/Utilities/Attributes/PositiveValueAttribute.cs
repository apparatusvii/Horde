﻿using UnityEngine;

namespace Febucci.UI.Core
{
    public class PositiveValueAttribute : PropertyAttribute
    {

    }

}