﻿using UnityEngine;

namespace Febucci.UI.Core
{
    public class CharsDisplayTimeAttribute : PropertyAttribute
    {
    }

}