﻿namespace Febucci.UI.Core
{
    //Do not add voices here
    //Add them into the CustomFeature enum, inside the CustomFunctionalities.cs script 
    public enum DefaultFeature
    {
        NotImplemented,

        WaitFor,
        WaitInput,
        TypewriterSpeedMult,
    }

}