﻿namespace Febucci.UI.Core
{
    public struct EventMarker
    {
        public int charIndex;
        public string eventMessage;
    }

}