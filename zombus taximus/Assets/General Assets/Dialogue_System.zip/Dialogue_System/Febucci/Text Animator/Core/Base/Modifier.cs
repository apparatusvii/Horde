﻿namespace Febucci.UI.Core
{
#if UNITY_EDITOR
    struct Modifier
    {
        public string name;
        public string value;
    }
#endif
}